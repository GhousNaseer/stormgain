# Stormgain_Bot
Full automated bot thats claims the Stormgain Miner, only for test purposes and learning!
The folder assignments are currently set to windows.



# To do:
* [Please register with a new account using the reflink from my buddy!](https://app.stormgain.com/friend/BNS16257368)
* If you don't know Python then please have a look at the [RELEASES](https://github.com/miningseven/Stormgain_Bot/releases).
* Install Python3+:
  ```shell
     python3 -m pip install selenium 
   ```
* Download the last Version from chromedriver.exe:
  * [chromedriver download](https://chromedriver.chromium.org/)
  * Place chromedriver.exe inside stormgain.py folder!
  * Make sure that Chromedriver and ChromeBrowser are on the same version!

* fill settings.json with your userdata
* run:
  ```shell
    python3 stormgain.py
    ``` 

# Additional
* [Here you can rent a fast and cheap VPS!](https://deinserverhost.de/store/aff.php?aff=3606)
* if you need support:
  * [Join Discord](https://discord.gg/YcDZskNUMp)
